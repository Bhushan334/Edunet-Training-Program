def fundamental_analysis(info):
    return {
        "Company": info.get("longName"),
        "Sector": info.get("sector"),
        "Market Cap": info.get("marketCap"),
        "PE": info.get("trailingPE"),
        "ROE": info.get("returnOnEquity"),
        "DebtEquity": info.get("debtToEquity"),
        "EPS": info.get("trailingEps")
    }
