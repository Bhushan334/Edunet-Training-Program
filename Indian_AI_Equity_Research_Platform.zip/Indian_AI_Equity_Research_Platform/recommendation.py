def investment_recommendation(f, sentiment, rsi):
    score = 0
    if f["PE"] and f["PE"] < 25: score += 1
    if f["ROE"] and f["ROE"] > 0.15: score += 1
    if rsi < 70: score += 1
    if sentiment == "Positive 📈": score += 1
    return "BUY ✅" if score >= 3 else "HOLD ⚖️" if score == 2 else "SELL ❌"
