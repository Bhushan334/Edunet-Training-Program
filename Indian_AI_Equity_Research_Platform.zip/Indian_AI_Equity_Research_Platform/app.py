import streamlit as st
from data_fetcher import get_stock_data
from fundamentals import fundamental_analysis
from sentiment import analyze_sentiment
from technicals import technical_indicators
from prediction import predict_price
from recommendation import investment_recommendation
from report_generator import generate_report
from pdf_generator import create_pdf

st.set_page_config(page_title="Forecast, Analyze, Invest with Confidence", layout="wide")
st.title("EquiSense – AI Equity Insights")

symbol = st.text_input("Enter Stock Symbol (e.g. TCS.NS)")

if st.button("Run Full Analysis"):
    info, data = get_stock_data(symbol)
    f = fundamental_analysis(info)
    data = technical_indicators(data)
    sentiment = analyze_sentiment(f["Company"])
    predicted = predict_price(data)
    rsi = data["RSI"].iloc[-1]
    rec = investment_recommendation(f, sentiment, rsi)
    st.line_chart(data[["Close", "MA50", "MA200"]])
    st.json(f)
    report = generate_report(f, sentiment, predicted, rec)
    st.text(report)
    pdf = create_pdf(report)
    st.download_button("Download PDF", open(pdf, "rb"), file_name="Equity_Report.pdf")
