def generate_report(f, sentiment, prediction, rec):
    return f"""AI EQUITY RESEARCH REPORT – INDIA

Company: {f['Company']}
Sector: {f['Sector']}

PE: {f['PE']}
ROE: {f['ROE']}
Debt/Equity: {f['DebtEquity']}

Sentiment: {sentiment}
Predicted Price (30 Days): ₹{prediction}

Recommendation: {rec}

Disclaimer: Educational use only.
"""
