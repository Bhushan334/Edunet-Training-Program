from sklearn.linear_model import LinearRegression
import numpy as np

def predict_price(data):
    data = data.dropna()
    X = np.arange(len(data)).reshape(-1, 1)
    y = data["Close"].values
    model = LinearRegression()
    model.fit(X, y)
    future_day = np.array([[len(data) + 30]])
    return round(model.predict(future_day)[0], 2)
