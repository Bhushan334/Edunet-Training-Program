from fpdf import FPDF

def safe_text(text):
    # Replace unsupported unicode characters
    replacements = {
        "₹": "Rs.",
        "–": "-",
        "—": "-",
        "📈": "",
        "📉": "",
        "⚖️": "",
        "🇮🇳": ""
    }
    for k, v in replacements.items():
        text = text.replace(k, v)
    return text.encode("latin-1", "ignore").decode("latin-1")

def create_pdf(report):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=11)

    clean_report = safe_text(report)

    for line in clean_report.split("\n"):
        pdf.multi_cell(0, 8, line)

    path = "Equity_Research_Report.pdf"
    pdf.output(path)
    return path
