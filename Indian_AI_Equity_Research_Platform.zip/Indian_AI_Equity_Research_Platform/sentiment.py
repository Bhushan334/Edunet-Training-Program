from textblob import TextBlob

def analyze_sentiment(company):
    headlines = [
        f"{company} posts strong quarterly earnings",
        f"{company} faces volatility in Indian markets",
        f"{company} long-term growth outlook remains positive"
    ]
    score = sum(TextBlob(h).sentiment.polarity for h in headlines) / len(headlines)
    if score > 0.1:
        return "Positive 📈"
    elif score < -0.1:
        return "Negative 📉"
    else:
        return "Neutral ⚖️"
